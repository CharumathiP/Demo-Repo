package tech.petrepopescu.logging.logback.maskers;

import tech.petrepopescu.logging.masker.IPMasker;

public class LogbackIpMasker extends IPMasker implements LogbackLogMasker {
}
