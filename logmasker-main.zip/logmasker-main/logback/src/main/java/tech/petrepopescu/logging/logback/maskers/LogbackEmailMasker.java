package tech.petrepopescu.logging.logback.maskers;

import tech.petrepopescu.logging.masker.EmailMasker;

public class LogbackEmailMasker extends EmailMasker implements LogbackLogMasker {
}
